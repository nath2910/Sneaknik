import './assets/main.css'
import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import './index.css'
import 'gridstack/dist/gridstack.min.css'
import './lib/echarts'
import VChart from 'vue-echarts'

console.log('VITE_API_BASE_URL =', import.meta.env.VITE_API_BASE_URL)
console.log('VITE_API_URL =', import.meta.env.VITE_API_URL)
window.addEventListener('error', (e) => {
  console.error('🔥 window.error', e.error || e.message, e)
})
window.addEventListener('unhandledrejection', (e) => {
  console.error('🔥 unhandledrejection', e.reason)
})

createApp(App).use(router).component('VChart', VChart).mount('#app')
