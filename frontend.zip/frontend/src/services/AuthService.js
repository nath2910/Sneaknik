import api from './api'

function extractToken(res) {
  const headerAuth = res.headers?.authorization || res.headers?.Authorization
  if (headerAuth?.startsWith('Bearer ')) return headerAuth.slice(7)
  return res.data?.token || res.data?.accessToken || null
}

class AuthService {
  async login(payload) {
    const res = await api.post('/auth/login', payload)

    const token = extractToken(res)
    const user = res.data?.user ?? null

    if (!token) throw new Error('Login OK mais aucun token reçu (header Authorization ou JSON)')

    return { user, token }
  }
}

export default new AuthService()
