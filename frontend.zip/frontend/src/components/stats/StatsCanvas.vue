<template>
  <div class="relative rounded-3xl border border-white/10 bg-[#070b14] overflow-hidden">
    <!-- Top toolbar -->
    <div class="absolute left-4 top-4 z-20 flex items-center gap-2">
      <button class="toolbtn" @click="paletteOpen = true" title="Ajouter un bloc">
        <Plus class="w-5 h-5" />
      </button>

      <div class="h-8 w-px bg-white/10 mx-1" />

      <button class="toolbtn" @click="zoomOut" title="Dézoomer">
        <Minus class="w-5 h-5" />
      </button>
      <button class="toolbtn w-[86px] justify-center" @click="resetZoom" title="Reset zoom">
        {{ Math.round(scale * 100) }}%
      </button>
      <button class="toolbtn" @click="zoomIn" title="Zoomer">
        <PlusSquare class="w-5 h-5" />
      </button>

      <button class="toolbtn" @click="centerView" title="Centrer">
        <LocateFixed class="w-5 h-5" />
      </button>

      <button class="toolbtn" @click="resetLayout" title="Reset layout">
        <RotateCcw class="w-5 h-5" />
      </button>
    </div>

    <!-- Canvas -->
    <div ref="viewportEl" class="viewport">
      <div ref="boardEl" class="board">
        <div
          v-for="w in widgets"
          :key="w.id"
          class="widget panzoom-exclude"
          :data-id="w.id"
          :style="widgetStyle(w)"
          @pointerdown.stop
        >
          <div class="widget__header">
            <div class="widget__handle">
              <span class="dot" />
              <span class="title">{{ w.title }}</span>
            </div>
            <button class="iconbtn" title="Supprimer" @click="removeWidget(w.id)">
              <Trash2 class="w-4 h-4" />
            </button>
          </div>

          <div class="widget__body">
            <component :is="getComp(w.type)" :from="from" :to="to" v-bind="w.props" />
          </div>

          <div class="widget__resize" />
        </div>
      </div>
    </div>

    <WidgetPalette
      :open="paletteOpen"
      :widgets="palette"
      @close="paletteOpen = false"
      @add="addWidget"
    />
  </div>
</template>

<script setup>
import { nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import Panzoom from '@panzoom/panzoom'
import interact from 'interactjs'
import { Plus, Minus, PlusSquare, LocateFixed, RotateCcw, Trash2 } from 'lucide-vue-next'

import WidgetPalette from './WidgetPalette.vue'
import { WIDGET_DEFS, getWidgetDef, newWidget } from './widgetRegistry'

const props = defineProps({
  from: { type: String, required: true },
  to: { type: String, required: true },
})

const from = props.from
const to = props.to

const viewportEl = ref(null)
const boardEl = ref(null)
let panzoom = null
const scale = ref(1)

const STORAGE_KEY = 'snk_stats_canvas_layout_v2'

const paletteOpen = ref(false)
const palette = WIDGET_DEFS.map((w) => ({
  type: w.type,
  title: w.title,
  icon: w.icon,
  help:
    w.type === 'line'
      ? 'Courbes CA/profit, zoomable'
      : w.type === 'kpis'
        ? 'Résumé rapide'
        : w.type === 'pie'
          ? 'Répartition par marques'
          : w.type === 'bar'
            ? 'Top marques en barres'
            : 'Top ventes sur la période',
}))

function getComp(type) {
  return getWidgetDef(type)?.component
}

function loadLayout() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

const defaultLayout = () => [
  { ...newWidget('kpis', 180, 160) },
  { ...newWidget('line', 180, 380) },
  { ...newWidget('pie', 980, 380) },
  { ...newWidget('bar', 180, 840) },
  { ...newWidget('top', 820, 840) },
]

const widgets = ref(loadLayout() ?? defaultLayout())

function saveLayout() {
  const minimal = widgets.value.map(({ id, type, title, x, y, w, h, props }) => ({
    id,
    type,
    title,
    x,
    y,
    w,
    h,
    props,
  }))
  localStorage.setItem(STORAGE_KEY, JSON.stringify(minimal))
}

watch(widgets, saveLayout, { deep: true })

function widgetStyle(w) {
  return { left: `${w.x}px`, top: `${w.y}px`, width: `${w.w}px`, height: `${w.h}px` }
}

function removeWidget(id) {
  const el = boardEl.value?.querySelector(`.widget[data-id="${id}"]`)
  if (el) interact(el).unset()
  widgets.value = widgets.value.filter((w) => w.id !== id)
}

function resetLayout() {
  // clean interact
  widgets.value.forEach((w) => {
    const el = boardEl.value?.querySelector(`.widget[data-id="${w.id}"]`)
    if (el) interact(el).unset()
  })
  widgets.value = defaultLayout()
  nextTick(initInteract)
  centerView()
}

function boardPointFromViewportCenter() {
  // on place le widget au centre visible
  const rect = viewportEl.value.getBoundingClientRect()
  const cx = rect.left + rect.width / 2
  const cy = rect.top + rect.height / 2
  const t = panzoom?.getTransform?.() ?? { x: 0, y: 0, scale: 1 }
  return {
    x: (cx - rect.left - t.x) / t.scale,
    y: (cy - rect.top - t.y) / t.scale,
  }
}

function addWidget(type) {
  paletteOpen.value = false
  const p = boardPointFromViewportCenter()
  const w = newWidget(type, Math.round(p.x - 120), Math.round(p.y - 80))
  widgets.value.push(w)
  nextTick(initInteract)
}

function zoomIn() {
  panzoom?.zoomIn()
  scale.value = panzoom?.getScale() ?? 1
}
function zoomOut() {
  panzoom?.zoomOut()
  scale.value = panzoom?.getScale() ?? 1
}
function resetZoom() {
  panzoom?.reset()
  scale.value = panzoom?.getScale() ?? 1
}
function centerView() {
  panzoom?.pan(-140, -120)
  scale.value = panzoom?.getScale() ?? 1
}

function initInteract() {
  widgets.value.forEach((w) => {
    const el = boardEl.value?.querySelector(`.widget[data-id="${w.id}"]`)
    if (!el) return

    interact(el)
      .draggable({
        allowFrom: '.widget__handle',
        listeners: {
          move(event) {
            const s = panzoom?.getScale?.() ?? 1
            w.x += event.dx / s
            w.y += event.dy / s
            // snap 10px
            w.x = Math.round(w.x / 10) * 10
            w.y = Math.round(w.y / 10) * 10
            el.style.left = `${w.x}px`
            el.style.top = `${w.y}px`
          },
        },
      })
      .resizable({
        edges: { right: true, bottom: true },
        listeners: {
          move(event) {
            const s = panzoom?.getScale?.() ?? 1
            w.w += event.deltaRect.width / s
            w.h += event.deltaRect.height / s
            w.w = Math.max(w.w, 320)
            w.h = Math.max(w.h, 220)
            w.w = Math.round(w.w / 10) * 10
            w.h = Math.round(w.h / 10) * 10
            el.style.width = `${w.w}px`
            el.style.height = `${w.h}px`
          },
        },
      })
  })
}

onMounted(async () => {
  panzoom = Panzoom(boardEl.value, {
    maxScale: 3,
    minScale: 0.2,
    contain: 'outside',
  })
  viewportEl.value.addEventListener('wheel', panzoom.zoomWithWheel, { passive: false })

  centerView()
  scale.value = panzoom.getScale()

  await nextTick()
  initInteract()
})

onBeforeUnmount(() => {
  if (viewportEl.value && panzoom)
    viewportEl.value.removeEventListener('wheel', panzoom.zoomWithWheel)
  panzoom = null
})
</script>

<style scoped>
.viewport {
  height: 72vh;
  position: relative;
}
.board {
  width: 5200px;
  height: 3600px;
  position: relative;

  /* deep lucide-grid vibe */
  background:
    radial-gradient(circle at 1px 1px, rgba(255, 255, 255, 0.08) 1px, transparent 0) 0 0/42px 42px,
    radial-gradient(circle at 1px 1px, rgba(255, 255, 255, 0.04) 1px, transparent 0) 0 0/10px 10px,
    radial-gradient(1200px 700px at 30% 20%, rgba(139, 92, 246, 0.12), transparent 60%),
    radial-gradient(1000px 600px at 70% 60%, rgba(56, 189, 248, 0.08), transparent 60%),
    linear-gradient(180deg, #070b14 0%, #050812 100%);
}

.toolbtn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 12px;
  border-radius: 14px;
  border: 1px solid rgba(255, 255, 255, 0.12);
  background: rgba(255, 255, 255, 0.06);
  color: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(8px);
}
.toolbtn:hover {
  background: rgba(255, 255, 255, 0.1);
}

.widget {
  position: absolute;
  border-radius: 22px;
  background: rgba(17, 24, 39, 0.82);
  border: 1px solid rgba(255, 255, 255, 0.1);
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.45);
  overflow: hidden;
}
.widget__header {
  height: 44px;
  display: flex;
  align-items: center;
  padding: 0 12px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
  background: rgba(10, 15, 30, 0.88);
}
.widget__handle {
  display: flex;
  align-items: center;
  gap: 10px;
  cursor: grab;
  user-select: none;
}
.dot {
  width: 10px;
  height: 10px;
  border-radius: 999px;
  background: #8b5cf6;
  box-shadow: 0 0 0 4px rgba(139, 92, 246, 0.15);
}
.title {
  color: rgba(255, 255, 255, 0.92);
  font-weight: 650;
  font-size: 0.9rem;
}
.iconbtn {
  margin-left: auto;
  width: 34px;
  height: 34px;
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  background: rgba(255, 255, 255, 0.05);
  color: rgba(255, 255, 255, 0.9);
  display: grid;
  place-items: center;
}
.iconbtn:hover {
  background: rgba(255, 255, 255, 0.1);
}
.widget__body {
  height: calc(100% - 44px);
  padding: 12px;
}
.widget__resize {
  position: absolute;
  right: 10px;
  bottom: 10px;
  width: 14px;
  height: 14px;
  border-right: 2px solid rgba(255, 255, 255, 0.55);
  border-bottom: 2px solid rgba(255, 255, 255, 0.55);
  border-radius: 2px;
  opacity: 0.7;
}
</style>
