// src/components/stats/widgetRegistry.js
import { Gauge, LineChart, PieChart, BarChart3, Trophy } from 'lucide-vue-next'

import StatsKpisWidget from './widgets/StatsKpisWidget.vue'
import StatsLineWidget from './widgets/StatsLineWidget.vue'
import StatsPieWidget from './widgets/StatsPieWidget.vue'
import StatsBarWidget from './widgets/StatsBarWidget.vue'
import StatsTopWidget from './widgets/StatsTopWidget.vue'

export const WIDGET_DEFS = [
  {
    type: 'kpis',
    title: 'KPIs',
    icon: Gauge,
    component: StatsKpisWidget,
    defaultSize: { w: 560, h: 190 },
    defaultProps: {},
  },
  {
    type: 'line',
    title: 'Courbes (CA & Profit)',
    icon: LineChart,
    component: StatsLineWidget,
    defaultSize: { w: 760, h: 420 },
    defaultProps: { granularity: 'day' },
  },
  {
    type: 'pie',
    title: 'Camembert (Marques)',
    icon: PieChart,
    component: StatsPieWidget,
    defaultSize: { w: 420, h: 420 },
    defaultProps: {},
  },
  {
    type: 'bar',
    title: 'Barres (Top marques)',
    icon: BarChart3,
    component: StatsBarWidget,
    defaultSize: { w: 600, h: 380 },
    defaultProps: { top: 8 },
  },
  {
    type: 'top',
    title: 'Top ventes',
    icon: Trophy,
    component: StatsTopWidget,
    defaultSize: { w: 560, h: 380 },
    defaultProps: { limit: 5 },
  },
]

export function getWidgetDef(type) {
  return WIDGET_DEFS.find((d) => d.type === type)
}

export function newWidget(type, x, y) {
  const uid =
    globalThis.crypto?.randomUUID?.() ?? `${Date.now()}_${Math.random().toString(16).slice(2)}`
  const def = getWidgetDef(type)
  if (!def) throw new Error(`Unknown widget type: ${type}`)
  return {
    id: `${type}_${uid}`,
    type,
    title: def.title,
    x,
    y,
    w: def.defaultSize.w,
    h: def.defaultSize.h,
    props: { ...def.defaultProps },
  }
}
