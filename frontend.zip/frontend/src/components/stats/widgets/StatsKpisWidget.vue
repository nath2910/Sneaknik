<template>
  <div class="space-y-3">
    <div class="grid grid-cols-2 lg:grid-cols-6 gap-3">
      <Kpi label="CA période" :value="fmt(summary.ca)" />
      <Kpi
        label="Bénéfice période"
        :value="fmt(summary.profit)"
        :tone="Number(summary.profit) >= 0 ? 'success' : 'danger'"
      />
      <Kpi label="Marge" :value="pct(summary.profitMargin)" tone="accent" />
      <Kpi label="Items vendus" :value="summary.itemsVendues" />
      <Kpi label="En stock" :value="summary.itemsEnStock" />
      <Kpi label="Valeur stock" :value="fmt(summary.valeurStock)" />
    </div>

    <p class="text-xs text-gray-500">
      Astuce : change la période en haut pour recalculer tous les modules.
    </p>
  </div>
</template>

<script setup>
import { onMounted, ref, watch } from 'vue'
import StatsServices from '@/services/StatsServices'
import Kpi from '@/components/StatBadge.vue'

const props = defineProps({ from: String, to: String })

const summary = ref({
  ca: 0,
  profit: 0,
  profitMargin: 0,
  itemsVendues: 0,
  itemsEnStock: 0,
  valeurStock: 0,
})

const currency = new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' })
const percent = new Intl.NumberFormat('fr-FR', { style: 'percent', maximumFractionDigits: 1 })

const fmt = (v) => currency.format(Number(v ?? 0))
const pct = (v) => percent.format(Number(v ?? 0))

async function load() {
  const { data } = await StatsServices.summary(props.from, props.to)
  summary.value = data
}

onMounted(load)
watch(() => [props.from, props.to], load)
</script>
