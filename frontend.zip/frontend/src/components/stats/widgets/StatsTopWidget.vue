<template>
  <div>
    <h3 class="text-sm font-semibold text-gray-100">Top ventes</h3>
    <p class="text-xs text-gray-400 mb-3">Ce qui t’a rapporté le plus sur la période.</p>

    <div v-if="loading" class="text-xs text-gray-400">Chargement...</div>
    <div v-else-if="!items.length" class="text-xs text-gray-500">Rien à afficher.</div>

    <ul v-else class="space-y-2 text-sm">
      <li v-for="(v, i) in items" :key="v.nomItem" class="flex justify-between items-center">
        <span class="text-gray-100">#{{ i + 1 }} {{ v.nomItem }}</span>
        <span class="text-emerald-400 font-semibold">{{ v.benefice }} €</span>
      </li>
    </ul>
  </div>
</template>

<script setup>
import { onMounted, ref, watch } from 'vue'
import StatsServices from '@/services/StatsServices'

const props = defineProps({
  from: { type: String, required: true },
  to: { type: String, required: true },
})

const loading = ref(true)
const items = ref([])

async function load() {
  loading.value = true
  try {
    const { data } = await StatsServices.topSales(props.from, props.to, 3)
    items.value = data
  } finally {
    loading.value = false
  }
}

onMounted(load)
watch(() => [props.from, props.to], load)
</script>
