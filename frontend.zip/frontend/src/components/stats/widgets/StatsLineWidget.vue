<template>
  <div class="h-full">
    <div class="flex items-center justify-between mb-2">
      <p class="text-xs text-gray-400">Évolution sur la période</p>
      <select v-model="granularity" class="select">
        <option value="day">Jour</option>
        <option value="week">Semaine</option>
      </select>
    </div>

    <VChart class="chart" :option="option" autoresize />
  </div>
</template>

<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import StatsServices from '@/services/StatsServices'

const props = defineProps({ from: String, to: String })

const granularity = ref('day')
const points = ref([])

async function load() {
  const { data } = await StatsServices.timeseries(props.from, props.to, granularity.value)
  points.value = data
}

onMounted(load)
watch(() => [props.from, props.to, granularity.value], load)

const option = computed(() => {
  const x = points.value.map((p) => p.date)
  const ca = points.value.map((p) => Number(p.ca))
  const profit = points.value.map((p) => Number(p.profit))

  return {
    backgroundColor: 'transparent',
    tooltip: { trigger: 'axis' },
    legend: { textStyle: { color: '#E5E7EB' } },
    grid: { left: 40, right: 20, top: 30, bottom: 40 },
    xAxis: {
      type: 'category',
      data: x,
      axisLabel: { color: '#9CA3AF' },
      axisLine: { lineStyle: { color: '#374151' } },
    },
    yAxis: {
      type: 'value',
      axisLabel: { color: '#9CA3AF' },
      splitLine: { lineStyle: { color: '#1F2937' } },
    },
    series: [
      { name: 'CA', type: 'line', smooth: true, data: ca, symbol: 'circle', symbolSize: 6 },
      {
        name: 'Bénéfice',
        type: 'line',
        smooth: true,
        data: profit,
        symbol: 'circle',
        symbolSize: 6,
      },
    ],
    color: ['#8B5CF6', '#10B981'],
  }
})
</script>

<style scoped>
.chart {
  width: 100%;
  height: 100%;
}
.select {
  background: rgba(17, 24, 39, 0.85);
  border: 1px solid rgba(55, 65, 81, 0.9);
  border-radius: 12px;
  padding: 6px 10px;
  color: #e5e7eb;
  font-size: 0.85rem;
}
</style>
