<template>
  <div class="h-full">
    <div class="flex items-center justify-between mb-2">
      <p class="text-xs text-gray-400">Ventes par marque</p>
      <select v-model="mode" class="select">
        <option value="donut">Donut</option>
        <option value="pie">Camembert</option>
      </select>
    </div>

    <VChart class="chart" :option="option" autoresize />
  </div>
</template>

<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import StatsServices from '@/services/StatsServices'

const props = defineProps({ from: String, to: String })
const mode = ref('donut')
const items = ref([])

async function load() {
  const { data } = await StatsServices.brands(props.from, props.to)
  items.value = data
}

onMounted(load)
watch(() => [props.from, props.to], load)

const option = computed(() => {
  const data = items.value.map((i) => ({ name: i.label, value: Number(i.nb) }))
  const donut = mode.value === 'donut'

  return {
    backgroundColor: 'transparent',
    tooltip: { trigger: 'item' },
    legend: { orient: 'vertical', left: 'left', textStyle: { color: '#E5E7EB' } },
    series: [
      {
        type: 'pie',
        radius: donut ? ['45%', '70%'] : '70%',
        center: ['60%', '55%'],
        avoidLabelOverlap: true,
        itemStyle: { borderRadius: 8, borderColor: '#0b1220', borderWidth: 2 },
        label: { color: '#E5E7EB', formatter: '{b}\n{d}%' },
        data,
      },
    ],
    color: ['#FF4560', '#008FFB', '#00E396', '#FEB019', '#775DD0', '#26a69a', '#D10CE8', '#546E7A'],
  }
})
</script>

<style scoped>
.chart {
  width: 100%;
  height: 100%;
}
.select {
  background: rgba(17, 24, 39, 0.85);
  border: 1px solid rgba(55, 65, 81, 0.9);
  border-radius: 12px;
  padding: 6px 10px;
  color: #e5e7eb;
  font-size: 0.85rem;
}
</style>
