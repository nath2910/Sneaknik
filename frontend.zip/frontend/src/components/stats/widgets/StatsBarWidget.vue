<template>
  <div class="h-full">
    <p class="text-xs text-gray-400 mb-2">Top marques (volume de ventes)</p>
    <VChart class="chart" :option="option" autoresize />
  </div>
</template>

<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import StatsServices from '@/services/StatsServices'

const props = defineProps({ from: String, to: String })
const items = ref([])

async function load() {
  const { data } = await StatsServices.brands(props.from, props.to)
  items.value = (data || []).slice(0, 8)
}

onMounted(load)
watch(() => [props.from, props.to], load)

const option = computed(() => {
  const labels = items.value.map(i => i.label)
  const values = items.value.map(i => Number(i.nb))

  return {
    backgroundColor: 'transparent',
    tooltip: { trigger: 'axis' },
    grid: { left: 90, right: 20, top: 10, bottom: 30 },
    xAxis: { type: 'value', axisLabel: { color: '#9CA3AF' }, splitLine: { lineStyle: { color: '#1F2937' } } },
    yAxis: { type: 'category', data: labels, axisLabel: { color: '#E5E7EB' }, axisLine: { lineStyle: { color: '#374151' } } },
    series: [{ type: 'bar', data: values, barWidth: 18, itemStyle: { borderRadius: [8,8,8,8] } }],
    color: ['#8B5CF6']
  }
})
</script>

<style scoped>
.chart { width: 100%; height: 100%; }
</style>
