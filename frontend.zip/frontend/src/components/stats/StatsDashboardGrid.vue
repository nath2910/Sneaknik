<template>
  <div>
    <div class="flex items-center justify-between mb-4">
      <div class="text-sm text-gray-400">
        Période : <span class="text-gray-200 font-semibold">{{ from }} → {{ to }}</span>
      </div>

      <button
        class="px-4 py-2 rounded-xl border border-gray-700 bg-gray-800 hover:bg-gray-700 text-gray-100"
        @click="toggleEdit"
      >
        {{ editMode ? 'Terminer' : 'Personnaliser' }}
      </button>
    </div>

    <div ref="gridEl" class="grid-stack">
      <div
        v-for="w in widgets"
        :key="w.id"
        class="grid-stack-item"
        :gs-id="w.id"
        :gs-x="w.x"
        :gs-y="w.y"
        :gs-w="w.w"
        :gs-h="w.h"
      >
        <div
          class="grid-stack-item-content rounded-3xl border border-gray-700 bg-gray-800 shadow-lg p-5 overflow-hidden"
        >
          <component :is="w.component" :from="from" :to="to" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref, watch } from 'vue'
import { GridStack } from 'gridstack'

import StatsKpis from './widgets/StatsKpisWidget.vue'
import StatsLineChart from './widgets/StatsLineWidget.vue'
import StatsBrandPie from './widgets/StatsPieWidget.vue'
import StatsTopSales from './widgets/StatsTopWidget.vue'

const props = defineProps({
  from: { type: String, required: true },
  to: { type: String, required: true },
})

const gridEl = ref(null)
const editMode = ref(false)
let grid = null

const STORAGE_KEY = 'snk_stats_layout_v1'

const defaultWidgets = [
  { id: 'kpis', x: 0, y: 0, w: 12, h: 2, component: StatsKpis },
  { id: 'line', x: 0, y: 2, w: 8, h: 4, component: StatsLineChart },
  { id: 'pie', x: 8, y: 2, w: 4, h: 4, component: StatsBrandPie },
  { id: 'top', x: 8, y: 6, w: 4, h: 3, component: StatsTopSales },
]

const widgets = ref(loadLayout() ?? defaultWidgets)

function loadLayout() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return null
    const saved = JSON.parse(raw)
    // On réinjecte les composants (car localStorage ne stocke pas les fonctions)
    const map = { kpis: StatsKpis, line: StatsLineChart, pie: StatsBrandPie, top: StatsTopSales }
    return saved.map((w) => ({ ...w, component: map[w.id] }))
  } catch {
    return null
  }
}

function saveLayout() {
  const minimal = widgets.value.map(({ id, x, y, w, h }) => ({ id, x, y, w, h }))
  localStorage.setItem(STORAGE_KEY, JSON.stringify(minimal))
}

function toggleEdit() {
  editMode.value = !editMode.value
  if (grid) grid.setStatic(!editMode.value)
}

onMounted(() => {
  grid = GridStack.init(
    {
      column: 12,
      cellHeight: 90,
      margin: 12,
      float: true,
      disableOneColumnMode: false,
    },
    gridEl.value,
  )

  grid.setStatic(true) // par défaut pas déplaçable

  grid.on('change', (event, items) => {
    // items = positions nouvelles
    items.forEach((it) => {
      const w = widgets.value.find((x) => x.id === it.id)
      if (w) {
        w.x = it.x
        w.y = it.y
        w.w = it.w
        w.h = it.h
      }
    })
    saveLayout()
  })
})
</script>

<style scoped>
/* On garde ton style, mais on évite que gridstack mette des backgrounds chelous */
.grid-stack-item-content {
  height: 100%;
}
</style>
