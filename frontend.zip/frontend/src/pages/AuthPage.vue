<template>
  <div>
    <AuthForm />
  </div>
</template>

<script setup lang="ts">
import AuthForm from '@/components/AuthAuthForm.vue'
</script>

<style></style>
