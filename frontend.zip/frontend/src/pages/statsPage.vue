<template>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
    <div>
      <div class="text-white text-2xl font-bold">Statistiques</div>
      <div class="text-white/60">
        Canvas dashboard • ajoute/organise tes blocs comme dans Lucidchart
      </div>
    </div>

    <DateRangeBar :from="from" :to="to" @update:from="setFrom" @update:to="setTo" />

    <StatsCanvas :from="from" :to="to" />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import DateRangeBar from '@/components/DateRangeBar.vue'
import StatsCanvas from '@/components/stats/StatsCanvas.vue'

const now = new Date()
const from = ref(new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10))
const to = ref(new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().slice(0, 10))

function setFrom(v) {
  from.value = v
}
function setTo(v) {
  to.value = v
}
</script>
